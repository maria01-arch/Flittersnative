import { useEffect, useMemo, useState } from 'react';
import { Modal, View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator, Alert, Keyboard } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/AuthContext';
import { useTheme } from '@/lib/ThemeContext';
import { postTime } from '@/lib/timeAgo';
import Avatar from './Avatar';
import ReportModal from './ReportModal';
import ActionSheet from './ActionSheet';

const SELECT = '*,author:profiles!comments_user_id_fkey(id,display_name,username,avatar_url),comment_likes(count)';
const countOf = (rel: any) => (Array.isArray(rel) ? Number(rel[0]?.count) || 0 : 0);

// Reel comments, TikTok-style: bubbles, like a comment, reply to a comment,
// and "View N replies" to open the replies under it. Replies are stored in the
// same `comments` table (reply_to_comment_id), like post comments.
export default function ReelCommentsSheet({
  reelId,
  postId,
  notifyUserId,
  visible,
  onClose,
  onCommentPosted,
}: {
  reelId: string | null;
  // When this reel is also a feed post, its comments are the post's comments too.
  postId?: string | null;
  notifyUserId?: string | null;
  visible: boolean;
  onClose: () => void;
  onCommentPosted?: () => void;
}) {
  const { session } = useAuth();
  const { colors } = useTheme();
  const me = session?.user?.id;
  const [comments, setComments] = useState<any[]>([]);
  const insets = useSafeAreaInsets();
  const [kbOpen, setKbOpen] = useState(false);
  useEffect(() => {
    const a = Keyboard.addListener('keyboardDidShow', () => setKbOpen(true));
    const b = Keyboard.addListener('keyboardDidHide', () => setKbOpen(false));
    return () => { a.remove(); b.remove(); };
  }, []);
  const [loading, setLoading] = useState(false);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [replyingTo, setReplyingTo] = useState<any>(null);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [menuFor, setMenuFor] = useState<any>(null);
  const [reportFor, setReportFor] = useState<any>(null);

  const decorate = (rows: any[], likedIds: Set<string>) =>
    rows.map((c) => ({ ...c, likes_count: countOf(c.comment_likes), liked_by_me: likedIds.has(c.id) }));

  useEffect(() => {
    if (!visible || !reelId) return;
    let cancelled = false;
    setLoading(true);
    setReplyingTo(null);
    setExpanded(new Set());
    (async () => {
      const q = supabase.from('comments').select(SELECT);
      const { data, error } = await (postId ? q.or(`reel_id.eq.${reelId},post_id.eq.${postId}`) : q.eq('reel_id', reelId)).order('created_at', { ascending: true });
      if (error) console.error('[ReelCommentsSheet] load failed:', error.message, error);
      const rows = data || [];
      const liked = new Set<string>();
      if (me && rows.length) {
        const { data: mine } = await supabase.from('comment_likes').select('comment_id').eq('user_id', me).in('comment_id', rows.map((r: any) => r.id));
        (mine || []).forEach((l: any) => liked.add(l.comment_id));
      }
      if (cancelled) return;
      setComments(decorate(rows, liked));
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [visible, reelId, postId]);

  // Top-level comments, and the replies grouped under each.
  const { topLevel, repliesOf } = useMemo(() => {
    const top: any[] = [];
    const map: Record<string, any[]> = {};
    comments.forEach((c) => {
      if (c.reply_to_comment_id) (map[c.reply_to_comment_id] = map[c.reply_to_comment_id] || []).push(c);
      else top.push(c);
    });
    return { topLevel: top, repliesOf: map };
  }, [comments]);

  const send = async () => {
    if (!text.trim() || !me || !reelId) return;
    setSending(true);
    const row: any = postId ? { post_id: postId, user_id: me, content: text.trim() } : { reel_id: reelId, user_id: me, content: text.trim() };
    // Replying to a reply attaches to the same top-level comment, so threads stay one level deep.
    if (replyingTo) row.reply_to_comment_id = replyingTo.reply_to_comment_id || replyingTo.id;
    const { data, error } = await supabase.from('comments').insert(row).select(SELECT).single();
    setSending(false);
    if (error || !data) {
      console.error('[ReelCommentsSheet] send failed:', error?.message, error);
      Alert.alert("Couldn't post", error?.message || 'Please try again.');
      return;
    }
    if (postId && notifyUserId && notifyUserId !== me) {
      supabase.from('notifications').insert({ user_id: notifyUserId, actor_id: me, type: 'comment', post_id: postId }).then(() => {});
    }
    setText('');
    setComments((prev) => [...prev, ...decorate([data], new Set())]);
    if (row.reply_to_comment_id) setExpanded((prev) => new Set(prev).add(row.reply_to_comment_id));
    setReplyingTo(null);
    onCommentPosted?.();
  };

  const toggleLike = async (c: any) => {
    if (!me) return;
    setComments((prev) => prev.map((x) => (x.id === c.id ? { ...x, liked_by_me: !x.liked_by_me, likes_count: x.likes_count + (x.liked_by_me ? -1 : 1) } : x)));
    if (c.liked_by_me) await supabase.from('comment_likes').delete().eq('comment_id', c.id).eq('user_id', me);
    else await supabase.from('comment_likes').insert({ comment_id: c.id, user_id: me });
  };

  const deleteComment = async (c: any) => {
    const { data, error } = await supabase.from('comments').delete().eq('id', c.id).eq('user_id', me!).select('id');
    if (error || !data?.length) {
      Alert.alert("Couldn't delete", error?.message || "The database didn't allow this delete. See the SQL fix in the chat.");
      return;
    }
    // Replies under a deleted comment go with it.
    await supabase.from('comments').delete().eq('reply_to_comment_id', c.id);
    setComments((prev) => prev.filter((x) => x.id !== c.id && x.reply_to_comment_id !== c.id));
    onCommentPosted?.();
  };

  const submitReport = async (reason: string, details: string) => {
    if (!me || !reportFor) return;
    const { error } = await supabase.from('reports').insert({ reporter_id: me, reported_comment_id: reportFor.id, reported_user_id: reportFor.author?.id, reason, details: details || null });
    if (error) throw error;
  };

  const openProfile = (userId?: string) => {
    if (!userId) return;
    onClose();
    router.push(`/user/${userId}`);
  };

  const renderComment = (c: any, isReply: boolean) => (
    <View key={c.id} style={[styles.row, isReply && { marginLeft: 44 }]}>
      <TouchableOpacity onPress={() => openProfile(c.author?.id)}>
        <Avatar uri={c.author?.avatar_url} size={isReply ? 28 : 36} />
      </TouchableOpacity>
      <View style={{ flex: 1 }}>
        <TouchableOpacity activeOpacity={0.8} onLongPress={() => setMenuFor(c)} style={{ backgroundColor: colors.inputBg, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 8 }}>
          <Text style={[styles.name, { color: colors.text }]}>{c.author?.display_name || 'Unknown'}</Text>
          <Text style={[styles.content, { color: colors.text }]}>{c.content}</Text>
        </TouchableOpacity>
        <View style={styles.meta}>
          <Text style={{ color: colors.faint, fontSize: 12 }}>{postTime(c.created_at)}</Text>
          <TouchableOpacity onPress={() => setReplyingTo(c)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <Text style={{ color: colors.subtext, fontSize: 12, fontWeight: '700' }}>Reply</Text>
          </TouchableOpacity>
        </View>
        {!isReply && (repliesOf[c.id]?.length || 0) > 0 && (
          <TouchableOpacity
            onPress={() =>
              setExpanded((prev) => {
                const n = new Set(prev);
                if (n.has(c.id)) n.delete(c.id);
                else n.add(c.id);
                return n;
              })
            }
            style={{ marginTop: 6 }}
          >
            <Text style={{ color: colors.subtext, fontSize: 12, fontWeight: '700' }}>
              {expanded.has(c.id) ? 'Hide replies' : `View ${repliesOf[c.id].length} ${repliesOf[c.id].length === 1 ? 'reply' : 'replies'}`}
            </Text>
          </TouchableOpacity>
        )}
      </View>
      <View style={{ alignItems: 'center', gap: 6 }}>
        <TouchableOpacity onPress={() => setMenuFor(c)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Ionicons name="ellipsis-horizontal" size={16} color={colors.faint} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => toggleLike(c)} style={{ alignItems: 'center' }} hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}>
          <Ionicons name={c.liked_by_me ? 'heart' : 'heart-outline'} size={18} color={c.liked_by_me ? '#EF4444' : colors.faint} />
          {c.likes_count > 0 && <Text style={{ color: colors.subtext, fontSize: 11 }}>{c.likes_count}</Text>}
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <TouchableOpacity style={styles.backdropTap} activeOpacity={1} onPress={onClose} />
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={[styles.sheet, { backgroundColor: colors.card }]}>
          <View style={styles.handle} />
          <View style={[styles.header, { borderBottomColor: colors.border }]}>
            <Text style={[styles.headerTitle, { color: colors.text }]}>Comments</Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={22} color={colors.subtext} />
            </TouchableOpacity>
          </View>

          {loading ? (
            <ActivityIndicator style={{ marginTop: 30 }} color={colors.primary} />
          ) : (
            <FlatList
              data={topLevel}
              keyExtractor={(item) => item.id}
              style={styles.list}
              ListEmptyComponent={<Text style={[styles.empty, { color: colors.subtext }]}>No comments yet. Say something!</Text>}
              renderItem={({ item }) => (
                <View>
                  {renderComment(item, false)}
                  {expanded.has(item.id) && (repliesOf[item.id] || []).map((r) => renderComment(r, true))}
                </View>
              )}
            />
          )}

          {replyingTo && (
            <View style={[styles.replyBar, { backgroundColor: colors.inputBg, borderTopColor: colors.border }]}>
              <Text style={{ color: colors.subtext, flex: 1 }} numberOfLines={1}>
                Replying to <Text style={{ fontWeight: '700', color: colors.text }}>{replyingTo.author?.display_name || 'comment'}</Text>
              </Text>
              <TouchableOpacity onPress={() => setReplyingTo(null)} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                <Ionicons name="close" size={18} color={colors.subtext} />
              </TouchableOpacity>
            </View>
          )}
          <View style={[styles.inputBar, { borderTopColor: colors.border, paddingBottom: 12 + (kbOpen ? 0 : insets.bottom) }]}>
            <TextInput
              style={[styles.input, { backgroundColor: colors.inputBg, color: colors.text }]}
              placeholder={replyingTo ? 'Write a reply...' : 'Add a comment...'}
              placeholderTextColor={colors.faint}
              value={text}
              onChangeText={setText}
            />
            <TouchableOpacity onPress={send} disabled={sending || !text.trim()}>
              {sending ? <ActivityIndicator size="small" color={colors.primary} /> : <Ionicons name="send" size={22} color={text.trim() ? colors.primary : colors.faint} />}
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>

        <ActionSheet
          visible={!!menuFor}
          onClose={() => setMenuFor(null)}
          options={
            menuFor
              ? menuFor.author?.id === me
                ? [{ label: 'Delete comment', icon: 'trash-outline', destructive: true, onPress: () => deleteComment(menuFor) }]
                : [{ label: 'Report comment', icon: 'flag-outline', onPress: () => setReportFor(menuFor) }]
              : []
          }
        />
        <ReportModal visible={!!reportFor} onClose={() => setReportFor(null)} onSubmit={submitReport} />
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.5)' },
  backdropTap: { flex: 1 },
  sheet: { height: '70%', borderTopLeftRadius: 22, borderTopRightRadius: 22, paddingBottom: 8 },
  handle: { alignSelf: 'center', width: 40, height: 4, borderRadius: 2, backgroundColor: 'rgba(128,128,128,0.4)', marginTop: 8 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1 },
  headerTitle: { fontSize: 16, fontWeight: '800' },
  list: { flex: 1 },
  empty: { textAlign: 'center', marginTop: 40 },
  row: { flexDirection: 'row', gap: 10, paddingHorizontal: 16, paddingVertical: 8 },
  name: { fontSize: 13, fontWeight: '700', marginBottom: 2 },
  content: { fontSize: 14, lineHeight: 20 },
  meta: { flexDirection: 'row', gap: 14, marginTop: 4, paddingLeft: 6 },
  replyBar: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 16, paddingVertical: 8, borderTopWidth: 1 },
  inputBar: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 12, paddingVertical: 12, borderTopWidth: 1 },
  input: { flex: 1, borderRadius: 22, paddingHorizontal: 16, paddingVertical: 11, fontSize: 16, minHeight: 44, maxHeight: 120 },
});
