import { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated, PanResponder, TouchableOpacity, Image, Modal, Pressable, PixelRatio, useWindowDimensions, Keyboard } from 'react-native';
import { optimizedUrl, markCdnBroken } from '@/lib/imageUrl';
import OptImage from './OptImage';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '@/lib/ThemeContext';
import MessageActionOverlay, { MenuAction, MenuRect } from './MessageActionOverlay';
import { isSingleEmoji } from '@/lib/emojiOnly';
import { STICKER_LABEL } from '@/lib/pins';
import { formatMessageTime } from '@/lib/formatTime';
import LinkifiedText from './LinkifiedText';
import LinkPreviewCard from './LinkPreviewCard';
import { getFirstUrl } from '@/lib/linkPreview';
import VoiceMessagePlayer from './VoiceMessagePlayer';
import StickerMedia from './StickerMedia';
import MessageVideoPlayer from './MessageVideoPlayer';

// A picture in a chat bubble: edge to edge (no padding, no frame) and shaped
// like the picture itself instead of a fixed square. Very wide / very tall
// pictures are limited so one image can't fill the whole screen. It measures
// and shows the same resized copy (see lib/imageUrl.ts).
function BubbleImage({ uri, previewUri, onPress, onLongPress, radius }: { uri: string; previewUri?: string; onPress: () => void; onLongPress: () => void; radius: number }) {
  const { width: screenW } = useWindowDimensions();
  const boxW = Math.min(240, Math.round(screenW * 0.62));
  const [useOriginal, setUseOriginal] = useState(false);
  const remote = useOriginal ? uri : optimizedUrl(uri, Math.ceil(boxW * PixelRatio.get())) || uri;
  // Until the uploaded picture is downloaded, keep showing the local one the
  // sender just picked, so there's no blank flash when the upload finishes.
  const [remoteReady, setRemoteReady] = useState(!previewUri);
  useEffect(() => {
    if (!previewUri) return;
    let cancelled = false;
    Image.prefetch(remote).then(() => !cancelled && setRemoteReady(true)).catch(() => !cancelled && setRemoteReady(true));
    return () => {
      cancelled = true;
    };
  }, [remote, previewUri]);
  const shown = previewUri && !remoteReady ? previewUri : remote;
  const [ratio, setRatio] = useState(1);
  useEffect(() => {
    let cancelled = false;
    Image.getSize(
      shown,
      (w, h) => {
        if (!cancelled && w > 0) setRatio(Math.min(3, Math.max(0.3, h / w)));
      },
      () => {
        if (shown !== uri && !useOriginal) {
          markCdnBroken();
          if (!cancelled) setUseOriginal(true);
        }
      }
    );
    return () => {
      cancelled = true;
    };
  }, [shown]);
  // Fit inside a box while keeping the picture's own shape: a 9:16 photo stays
  // tall and narrow, a square stays square, a wide one stays wide.
  const MAX_H = 340;
  let shownW = boxW;
  let shownH = boxW * ratio;
  if (shownH > MAX_H) {
    shownH = MAX_H;
    shownW = MAX_H / ratio;
  }
  return (
    <Pressable onPress={onPress} onLongPress={onLongPress} delayLongPress={220}>
      <Image
        source={{ uri: shown }}
        style={{ width: shownW, height: shownH, borderRadius: radius, backgroundColor: 'rgba(0,0,0,0.08)' }}
        resizeMode="cover"
        onError={() => {
          if (shown !== uri && !useOriginal) {
            markCdnBroken();
            setUseOriginal(true);
          }
        }}
      />
    </Pressable>
  );
}

export default function MessageBubble({
  message,
  isMine,
  currentUserId,
  senderAvatar,
  senderName,
  showSender,
  isPinned,
  isRead,
  showTimestamp = true,
  tightTop = false,
  onReply,
  onPressReply,
  onStickerPress,
  highlighted,
  myBubbleColor,
  onCopy,
  onEdit,
  onDelete,
  onReact,
  onPin,
  onRetry,
  onReport,
  onShowReactors,
  onShowSeenBy,
  onForward,
  compactReactions = false,
  replySticker,
}: {
  message: any;
  isMine: boolean;
  currentUserId?: string;
  senderAvatar?: string;
  senderName?: string;
  showSender?: boolean;
  isPinned?: boolean;
  isRead?: boolean;
  showTimestamp?: boolean;
  tightTop?: boolean;
  onReply: (m: any) => void;
  // Tapping the quoted text jumps to the original message.
  onPressReply?: () => void;
  onStickerPress?: (m: any) => void;
  highlighted?: boolean;
  // Chosen chat theme colour for MY bubbles (verified members only).
  myBubbleColor?: string;
  onCopy: (m: any) => void;
  onEdit: (m: any) => void;
  onDelete: (m: any) => void;
  onReact: (m: any, emoji: string) => void;
  onPin: (m: any) => void;
  onRetry?: (m: any) => void;
  onReport?: (m: any) => void;
  // Group only: long-press a reaction to see who reacted / long-press a message to see who saw it.
  onShowReactors?: (m: any) => void;
  onShowSeenBy?: (m: any) => void;
  // Send this message (text / picture / video / sticker / voice) to other chats.
  onForward?: (m: any) => void;
  // Tighter space under the bubble (groups).
  compactReactions?: boolean;
  // Picture of the sticker this message replies to (shown small in the quote).
  replySticker?: string;
}) {
  const { colors } = useTheme();
  const [sheetOpen, setSheetOpen] = useState(false);
  const [menuRect, setMenuRect] = useState<MenuRect | null>(null);
  const [fullscreenImage, setFullscreenImage] = useState(false);
  // Long messages show the first 15 lines, then "See more". The limit is
  // applied right away (no flash of the whole text); a hidden copy of the
  // text, laid out with no limit, counts the real number of lines, because
  // Android only reports the lines that are shown when a limit is set.
  const [textOpen, setTextOpen] = useState(false);
  const [textLines, setTextLines] = useState<number | null>(null);
  const TEXT_LINES = 15;
  useEffect(() => {
    setTextLines(null);
    setTextOpen(false);
  }, [message.content]);
  const textLongish = String(message.content || '').length > 150;
  const textLong = textLines !== null && textLines > TEXT_LINES;
  const textLimit = textLongish && !textOpen && (textLines === null || textLong) ? TEXT_LINES : undefined;
  const textBase = isMine ? styles.myText : [styles.theirText, { color: colors.text }];
  const textMeasurer =
    textLongish && textLines === null ? (
      <LinkifiedText
        text={message.content}
        style={[textBase, { position: 'absolute', left: 0, right: 0, top: 0, opacity: 0 }] as any}
        linkColor="transparent"
        onTextLayout={(e: any) => setTextLines(e.nativeEvent.lines.length)}
      />
    ) : null;
  const translateX = useRef(new Animated.Value(0)).current;
  const bodyRef = useRef<View>(null);

  const panResponder = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dx) > 8 && Math.abs(g.dx) > Math.abs(g.dy),
      onPanResponderMove: (_, g) => {
        if (g.dx > 0) translateX.setValue(Math.min(g.dx, 70));
      },
      onPanResponderRelease: (_, g) => {
        if (g.dx > 50) onReply(message);
        Animated.spring(translateX, { toValue: 0, useNativeDriver: true }).start();
      },
    })
  ).current;

  const reactions: any[] = message.reactions || [];
  const grouped: Record<string, number> = {};
  reactions.forEach((r) => {
    grouped[r.emoji] = (grouped[r.emoji] || 0) + 1;
  });
  const myReaction = reactions.find((r) => r.user_id === currentUserId)?.emoji;
  // At most 4 different emojis are drawn. Everything beyond that is added up in
  // one "+N" pill, so the row never grows wider than the bubble. Your own
  // reaction is always kept visible.
  const sortedReactions = Object.entries(grouped).sort((a, b) => b[1] - a[1]);
  let shownReactions = sortedReactions.slice(0, 4);
  if (myReaction && !shownReactions.some(([e]) => e === myReaction) && grouped[myReaction]) {
    shownReactions = [...shownReactions.slice(0, 3), [myReaction, grouped[myReaction]]];
  }
  const hiddenReactionCount = sortedReactions.filter(([e]) => !shownReactions.some(([s]) => s === e)).reduce((sum, [, c]) => sum + c, 0);
  // Groups: all reactions live in ONE small bubble (up to 3 different emojis, then the total).
  let bubbleEmojis = sortedReactions.slice(0, 3).map(([e]) => e);
  if (myReaction && !bubbleEmojis.includes(myReaction)) bubbleEmojis = [...bubbleEmojis.slice(0, 2), myReaction];
  const isVoice = !!(message.is_voice && message.voice_url);
  const isSticker = !!(message.is_sticker && message.sticker_url);
  const isVideo = !!(message.video_url && !isVoice && !isSticker);
  const isImage = !!(message.image_url && !isVoice && !isSticker && !isVideo);
  const isPending = !!message._pending;
  const isFailed = !!message._failed;
  // One emoji and nothing else: shown big, with no bubble.
  const isEmojiOnly = !isVoice && !isSticker && !isVideo && !isImage && !message.reply_to && isSingleEmoji(message.content);
  const stickerQuote = !!replySticker && !/\.(webm|mp4|mov|m4v)($|\?)/i.test(replySticker);

  // Long press: measure where the message sits on the screen, then open the menu there.
  const openMenuNow = () => {
    const node: any = bodyRef.current;
    if (node?.measureInWindow) {
      node.measureInWindow((x: number, y: number, w: number, h: number) => {
        setMenuRect({ x, y, w, h });
        setSheetOpen(true);
      });
    } else {
      setMenuRect({ x: 12, y: 200, w: 240, h: 60 });
      setSheetOpen(true);
    }
  };
  // With the keyboard open, the chat moves when the keyboard closes (opening the
  // menu closes it), so the message was measured at the wrong place. Close the
  // keyboard first, wait for the chat to settle, then measure.
  const openMenu = () => {
    let kbVisible = false;
    try {
      kbVisible = !!Keyboard.isVisible?.();
    } catch {}
    if (!kbVisible) {
      openMenuNow();
      return;
    }
    let done = false;
    const go = () => {
      if (done) return;
      done = true;
      sub.remove();
      clearTimeout(fallback);
      setTimeout(openMenuNow, 140);
    };
    const sub = Keyboard.addListener('keyboardDidHide', go);
    const fallback = setTimeout(go, 600);
    Keyboard.dismiss();
  };
  const closeMenu = () => setSheetOpen(false);
  const doAfterClose = (fn: () => void) => () => {
    setSheetOpen(false);
    fn();
  };

  const linkUrl = !isSticker && !isVoice && !isVideo && !isImage && !isEmojiOnly && message.content ? getFirstUrl(String(message.content)) : null;
  const canEdit = isMine && !isVoice && !isSticker && !isVideo && !isPending && !isFailed;
  const actions: MenuAction[] = [
    { key: 'reply', label: 'Reply', icon: 'arrow-undo-outline', onPress: doAfterClose(() => onReply(message)) },
    ...(message.content && String(message.content).trim() && !isVoice && !isSticker
      ? [{ key: 'copy', label: 'Copy', icon: 'copy-outline', onPress: doAfterClose(() => onCopy(message)) }]
      : []),
    ...(onForward && !isPending && !isFailed
      ? [{ key: 'forward', label: 'Forward', icon: 'arrow-redo-outline', onPress: doAfterClose(() => onForward(message)) }]
      : []),
    ...(!isPending && !isFailed
      ? [{ key: 'pin', label: isPinned ? 'Unpin' : 'Pin', icon: isPinned ? 'pin' : 'pin-outline', onPress: doAfterClose(() => onPin(message)) }]
      : []),
    ...(onShowSeenBy && isMine && !isPending && !isFailed
      ? [{ key: 'seen', label: 'Seen by', icon: 'eye-outline', onPress: doAfterClose(() => onShowSeenBy(message)) }]
      : []),
    ...(canEdit ? [{ key: 'edit', label: 'Edit', icon: 'create-outline', onPress: doAfterClose(() => onEdit(message)) }] : []),
    { key: 'delete', label: 'Delete', icon: 'trash-outline', danger: true, onPress: doAfterClose(() => onDelete(message)) },
    ...(!isMine && onReport ? [{ key: 'report', label: 'Report', icon: 'flag-outline', danger: true, onPress: doAfterClose(() => onReport(message)) }] : []),
  ];

  // The message itself (name, bubble, reactions, time). It is drawn twice: in the
  // chat, and again (preview = true, no touches) inside the long-press menu.
  const renderBody = (preview: boolean) => (
    <>
      {!isMine && showSender && senderName && !tightTop && <Text style={[styles.senderName, { color: colors.subtext }]}>{senderName}</Text>}
      {isPinned && (
        <View style={[styles.pinRow, isMine ? { justifyContent: 'flex-end' } : { justifyContent: 'flex-start' }]}>
          <Ionicons name="pin" size={11} color={colors.faint} />
          <Text style={[styles.pinLabel, { color: colors.faint }]}>Pinned</Text>
        </View>
      )}
      {!!message.is_forwarded && (
        <View style={[styles.pinRow, isMine ? { justifyContent: 'flex-end' } : { justifyContent: 'flex-start' }]}>
          <Ionicons name="arrow-redo" size={11} color={colors.faint} />
          <Text style={[styles.pinLabel, { color: colors.faint, fontStyle: 'italic' }]}>Forwarded</Text>
        </View>
      )}
      <View
        style={[
          !isSticker && styles.bubble,
          !isSticker && (isMine ? { backgroundColor: myBubbleColor || colors.primary } : { backgroundColor: colors.bubbleTheirs }),
          isVoice && styles.voiceBubble,
          (isImage || isVideo) && styles.imageBubble,
          // A picture on its own has no bubble at all; with a caption it gets a
          // thin one (4px) around picture + text.
          isImage && !message.content && { backgroundColor: 'transparent' },
          isImage && !!message.content && { padding: 4, maxWidth: 320 },
          // A single emoji: big, no bubble.
          isEmojiOnly && { backgroundColor: 'transparent', paddingHorizontal: 2, paddingVertical: 0 },
        ]}
      >
        {message.reply_to ? (
          <TouchableOpacity
            activeOpacity={0.7}
            disabled={preview}
            onPress={onPressReply}
            style={[
              styles.replyQuote,
              { borderLeftColor: isMine && !isSticker ? 'rgba(255,255,255,0.6)' : colors.primary },
              (stickerQuote || isSticker) && { flexDirection: 'row', alignItems: 'center', gap: 6 },
              // A sticker has no bubble to hold the quote, so the quote gets its own small pill.
              isSticker && { backgroundColor: colors.bubbleTheirs, borderRadius: 10, paddingVertical: 5, paddingRight: 8, marginBottom: 4 },
            ]}
          >
            {stickerQuote ? <StickerMedia url={replySticker as string} size={30} /> : null}
            <Text
              style={[styles.replyQuoteText, { flexShrink: 1, color: isMine && !isSticker ? 'rgba(255,255,255,0.85)' : colors.subtext }]}
              numberOfLines={1}
            >
              {message.reply_to}
            </Text>
          </TouchableOpacity>
        ) : null}
        {isSticker ? (
          // Tap someone else's sticker to save it (or its whole pack).
          <Pressable disabled={preview} onPress={() => !isMine && onStickerPress?.(message)} onLongPress={openMenu} delayLongPress={220}>
            <StickerMedia url={message.sticker_url} size={132} />
          </Pressable>
        ) : isVoice ? (
          <VoiceMessagePlayer url={message.voice_url} duration={message.voice_duration} isMine={isMine} onLongPress={preview ? undefined : openMenu} />
        ) : isVideo ? (
          <MessageVideoPlayer url={message.video_url} />
        ) : isImage ? (
          // A tap opens the image fullscreen — this used to sit inside a
          // TouchableOpacity that only had onLongPress wired up, so taps
          // did nothing at all. The long-press message menu still works
          // the same way, just moved onto this element directly.
          <View>
            <BubbleImage uri={message.image_url} previewUri={message.localImage} radius={message.content ? 12 : 16} onPress={() => !preview && setFullscreenImage(true)} onLongPress={() => !preview && openMenu()} />
            {!!message.content && (
              // A caption travels in the same bubble as its picture.
              <View style={{ paddingHorizontal: 12, paddingVertical: 8 }}>
                <View>
                <LinkifiedText
                  text={message.content}
                  style={isMine ? styles.myText : [styles.theirText, { color: colors.text }]}
                  linkColor={isMine ? '#D6E4FF' : colors.primary}
                  numberOfLines={textLimit}
                />
                  {textMeasurer}
                </View>
                {textLong && (
                  <Text onPress={() => setTextOpen((v) => !v)} style={{ color: isMine ? '#D6E4FF' : colors.primary, fontWeight: '700', marginTop: 4 }}>{textOpen ? 'See less' : 'See more'}</Text>
                )}
              </View>
            )}
          </View>
        ) : isEmojiOnly ? (
          <Text style={styles.bigEmoji}>{String(message.content).trim()}</Text>
        ) : (
          <>
            <View>
              <LinkifiedText
                text={message.content}
                style={isMine ? styles.myText : [styles.theirText, { color: colors.text }]}
                linkColor={isMine ? '#D6E4FF' : colors.primary}
                numberOfLines={textLimit}
              />
              {textMeasurer}
            </View>
            {textLong && (
              <Text onPress={() => setTextOpen((v) => !v)} style={{ color: isMine ? '#D6E4FF' : colors.primary, fontWeight: '700', marginTop: 4 }}>{textOpen ? 'See less' : 'See more'}</Text>
            )}
            {!preview && !!linkUrl && (
              <View style={{ width: 232 }}>
                <LinkPreviewCard url={linkUrl} onDark={isMine} />
              </View>
            )}
          </>
        )}
      </View>
      {/* Reactions sit ON the bubble's bottom edge (WhatsApp-style), above the
          time and tick marks. Up to 4 emojis, then one "+N" for the rest. Press a
          pill to react the same; long-press (groups) to see who reacted. */}
      {compactReactions && reactions.length > 0 && (
        <View style={[styles.reactionsRow, styles.reactionsRowCompact, isMine ? { alignSelf: 'flex-end', marginRight: 10 } : { alignSelf: 'flex-start', marginLeft: 10 }]}>
          <TouchableOpacity
            disabled={preview}
            style={[styles.reactionPill, styles.reactionPillCompact, { backgroundColor: colors.card, borderColor: colors.border }, !!myReaction && { borderColor: colors.primary }]}
            onPress={() => onShowReactors?.(message)}
            onLongPress={() => onShowReactors?.(message)}
            delayLongPress={250}
          >
            <Text style={styles.reactionEmoji}>{bubbleEmojis.join('')}</Text>
            {reactions.length > 1 && <Text style={[styles.reactionCount, { color: colors.subtext }]}>{reactions.length}</Text>}
          </TouchableOpacity>
        </View>
      )}
      {!compactReactions && shownReactions.length > 0 && (
        <View
          style={[
            styles.reactionsRow,
            compactReactions && styles.reactionsRowCompact,
            isMine ? { alignSelf: 'flex-end', marginRight: 10 } : { alignSelf: 'flex-start', marginLeft: 10 },
          ]}
        >
          {shownReactions.map(([emoji, count]) => (
            <TouchableOpacity
              key={emoji}
              disabled={preview}
              style={[styles.reactionPill, compactReactions && styles.reactionPillCompact, { backgroundColor: colors.card, borderColor: colors.border }, myReaction === emoji && { borderColor: colors.primary }]}
              onPress={() => onReact(message, emoji)}
              onLongPress={onShowReactors ? () => onShowReactors(message) : undefined}
              delayLongPress={250}
            >
              <Text style={styles.reactionEmoji}>{emoji}</Text>
              {count > 1 && <Text style={[styles.reactionCount, { color: colors.subtext }]}>{count}</Text>}
            </TouchableOpacity>
          ))}
          {hiddenReactionCount > 0 && (
            <TouchableOpacity
              disabled={preview}
              style={[styles.reactionPill, compactReactions && styles.reactionPillCompact, { backgroundColor: colors.card, borderColor: colors.border }]}
              onPress={() => onShowReactors?.(message)}
              onLongPress={onShowReactors ? () => onShowReactors(message) : undefined}
            >
              <Text style={[styles.reactionCount, { color: colors.subtext }]}>+{hiddenReactionCount}</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
      {showTimestamp && (
        <View style={[styles.metaRow, compactReactions && reactions.length > 0 && { marginTop: 0 }, isMine ? { alignSelf: 'flex-end' } : { alignSelf: 'flex-start' }]}>
          {isFailed ? (
            <TouchableOpacity style={styles.retryRow} disabled={preview} onPress={() => onRetry?.(message)} hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}>
              <Ionicons name="alert-circle" size={12} color={colors.danger} />
              <Text style={[styles.retryText, { color: colors.danger }]}>Not sent · Tap to retry</Text>
            </TouchableOpacity>
          ) : (
            <>
              <Text style={[styles.timeText, { color: colors.faint }]}>{message.edited_at ? 'edited · ' : ''}{formatMessageTime(message.created_at)}</Text>
              {isMine && isPending ? (
                <Ionicons name="time-outline" size={12} color={colors.faint} style={{ marginLeft: 3 }} />
              ) : (
                isMine &&
                isRead !== undefined && (
                  <Ionicons name={isRead ? 'checkmark-done' : 'checkmark'} size={13} color={isRead ? colors.primary : colors.faint} style={{ marginLeft: 3 }} />
                )
              )}
            </>
          )}
        </View>
      )}
    </>
  );

  return (
    <View style={[styles.row, isMine ? styles.myRow : styles.theirRow, tightTop && styles.rowTight, highlighted && { backgroundColor: 'rgba(250,204,21,0.28)' }]}>
      {!isMine && showSender && (
        <Image source={{ uri: senderAvatar || 'https://placehold.co/60x60/1D8FEA/fff?text=?' }} style={[styles.avatar, tightTop && styles.avatarHidden]} />
      )}
      <Animated.View ref={bodyRef as any} collapsable={false} style={{ transform: [{ translateX }] }} {...panResponder.panHandlers}>
        <TouchableOpacity activeOpacity={0.85} onLongPress={openMenu} delayLongPress={220}>
          {renderBody(false)}
        </TouchableOpacity>
      </Animated.View>

      <MessageActionOverlay
        visible={sheetOpen}
        rect={menuRect}
        isMine={isMine}
        actions={actions}
        onClose={closeMenu}
        onReact={(emoji) => {
          setSheetOpen(false);
          onReact(message, emoji);
        }}
      >
        <View pointerEvents="none">{renderBody(true)}</View>
      </MessageActionOverlay>

      {isImage && (
        <Modal visible={fullscreenImage} transparent animationType="fade" onRequestClose={() => setFullscreenImage(false)}>
          <Pressable style={styles.fullscreenBackdrop} onPress={() => setFullscreenImage(false)}>
            <Image source={{ uri: message.image_url }} style={styles.fullscreenImage} resizeMode="contain" />
          </Pressable>
        </Modal>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', paddingHorizontal: 12, marginVertical: 4, alignItems: 'flex-end', gap: 8 },
  rowTight: { marginVertical: 1 },
  myRow: { justifyContent: 'flex-end' },
  theirRow: { justifyContent: 'flex-start' },
  avatar: { width: 26, height: 26, borderRadius: 13, backgroundColor: '#ddd' },
  avatarHidden: { opacity: 0 },
  senderName: { fontSize: 11, marginBottom: 2, marginLeft: 4 },
  pinRow: { flexDirection: 'row', alignItems: 'center', gap: 3, marginBottom: 2 },
  pinLabel: { fontSize: 10, fontWeight: '600' },
  bubble: { maxWidth: 260, borderRadius: 18, paddingHorizontal: 14, paddingVertical: 10 },
  voiceBubble: { paddingVertical: 8, minWidth: 210 },
  imageBubble: { padding: 0, overflow: 'hidden' },
  messageImage: { width: 220, height: 220, backgroundColor: 'rgba(0,0,0,0.08)' },
  replyQuote: { borderLeftWidth: 3, paddingLeft: 8, marginBottom: 5 },
  replyQuoteText: { fontSize: 12.5 },
  myText: { color: '#fff', fontSize: 15 },
  theirText: { fontSize: 15 },
  bigEmoji: { fontSize: 34, lineHeight: 42 },
  metaRow: { flexDirection: 'row', alignItems: 'center', marginTop: 2, paddingHorizontal: 4 },
  timeText: { fontSize: 10.5 },
  retryRow: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  retryText: { fontSize: 10.5, fontWeight: '600' },
  reactionsRow: { flexDirection: 'row', gap: 4, marginTop: -9, marginBottom: 3, zIndex: 2 },
  reactionsRowCompact: { gap: 3, marginTop: -8, marginBottom: 0 },
  reactionPill: { flexDirection: 'row', alignItems: 'center', gap: 3, borderRadius: 12, borderWidth: 1, paddingHorizontal: 6, paddingVertical: 2 },
  reactionPillCompact: { paddingHorizontal: 5, paddingVertical: 1, gap: 2 },
  reactionEmoji: { fontSize: 13 },
  reactionCount: { fontSize: 11, fontWeight: '600' },
  fullscreenBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.92)', justifyContent: 'center' },
  fullscreenImage: { width: '100%', height: '100%' },
});
