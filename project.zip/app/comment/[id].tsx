import { useEffect, useState } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator, KeyboardAvoidingView, Platform, Alert, Image } from 'react-native';
import PasteTextInput from '@/components/PasteTextInput';
import { useClipboardImage } from '@/lib/clipboardImage';
import PasteImageChip from '@/components/PasteImageChip';
import { useLocalSearchParams, router } from 'expo-router';
import Ionicons from '@expo/vector-icons/Ionicons';
import { supabase } from '@/lib/supabase';
import { useTheme } from '@/lib/ThemeContext';
import { useAuth } from '@/lib/AuthContext';
import KeyboardWrap from '@/components/KeyboardWrap';
import CommentCard from '@/components/CommentCard';
import { loadCommentTree, pickCommentImage } from '@/lib/comments';
import { uploadImage } from '@/lib/upload';
import { canPerform, permissionDeniedMessage } from '@/lib/permissions';

export default function CommentThreadScreen() {
  const { id, postId } = useLocalSearchParams();
  const { session } = useAuth();
  const { colors } = useTheme();
  const [root, setRoot] = useState<any>(null);
  const [replies, setReplies] = useState<any[]>([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [replyImage, setReplyImage] = useState<string | null>(null);
  const clip = useClipboardImage();

  const load = async () => {
    const { all, byId } = await loadCommentTree(postId as string, session?.user?.id);
    setRoot(byId[id as string] || null);
    setReplies(all.filter((c: any) => c.reply_to_comment_id === id));
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, [id, postId]);

  const toggleLike = async (c: any, isRoot = false) => {
    if (!session?.user?.id) return;
    const update = (x: any) => (x.id === c.id ? { ...x, liked_by_me: !x.liked_by_me, likes_count: x.liked_by_me ? x.likes_count - 1 : x.likes_count + 1 } : x);
    if (isRoot) setRoot((r: any) => update(r));
    else setReplies((prev) => prev.map(update));
    if (c.liked_by_me) {
      await supabase.from('comment_likes').delete().eq('comment_id', c.id).eq('user_id', session.user.id);
    } else {
      await supabase.from('comment_likes').insert({ comment_id: c.id, user_id: session.user.id });
    }
  };

  const toggleRepost = async (c: any, isRoot = false) => {
    if (!session?.user?.id) return;
    const update = (x: any) => (x.id === c.id ? { ...x, reposted_by_me: !x.reposted_by_me, reposts_count: x.reposted_by_me ? x.reposts_count - 1 : x.reposts_count + 1 } : x);
    if (isRoot) setRoot((r: any) => update(r));
    else setReplies((prev) => prev.map(update));
    if (c.reposted_by_me) {
      await supabase.from('comment_reposts').delete().eq('comment_id', c.id).eq('user_id', session.user.id);
    } else {
      await supabase.from('comment_reposts').insert({ comment_id: c.id, user_id: session.user.id });
    }
  };

  const submitReply = async () => {
    if ((!text.trim() && !replyImage) || !session?.user?.id || !root) return;
    // A reply is still a comment on the original post, so it's gated by
    // that post's who_can_comment — fetched here rather than on every
    // screen load, since replying is the only moment it matters.
    const { data: post } = await supabase.from('posts').select('user_id,author:profiles!user_id(who_can_comment)').eq('id', postId).single();
    const allowed = await canPerform((post?.author as any)?.who_can_comment, post?.user_id, session.user.id);
    if (!allowed) {
      Alert.alert("Can't comment", permissionDeniedMessage('who can comment on their posts', (post?.author as any)?.who_can_comment));
      return;
    }
    setSending(true);
    let imageUrl: string | null = null;
    if (replyImage) {
      imageUrl = await uploadImage(replyImage, `posts/${session.user.id}`);
      if (!imageUrl) {
        Alert.alert("Couldn't upload the picture", 'Check your connection and try again.');
        setSending(false);
        return;
      }
    }
    const { error: rErr } = await supabase.from('comments').insert({
      post_id: postId,
      user_id: session.user.id,
      content: text.trim(),
      reply_to_comment_id: root.id,
      ...(imageUrl ? { image_url: imageUrl } : {}),
    });
    if (rErr) {
      Alert.alert("Couldn't post", rErr.message);
      setSending(false);
      return;
    }
    if (root.user_id && root.user_id !== session.user.id) {
      await supabase.from('notifications').insert({ user_id: root.user_id, actor_id: session.user.id, type: 'comment', post_id: postId });
    }
    setText('');
    setReplyImage(null);
    await load();
    setSending(false);
  };

  if (loading || !root) {
    return (
      <View style={[styles.center, { backgroundColor: colors.bg }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <KeyboardWrap style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={[styles.topBar, { borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={[styles.topBarTitle, { color: colors.text }]}>Reply</Text>
        <View style={{ width: 24 }} />
      </View>
      <FlatList
        data={replies}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={
          <CommentCard
            comment={root}
            postId={postId as string}
            currentUserId={session?.user?.id}
            navigable={false}
            onLike={(c) => toggleLike(c, true)}
            onRepost={(c) => toggleRepost(c, true)}
            // Deleting the root comment of this thread leaves nothing left
            // to show here — the post's own comment list (one screen back)
            // is what actually reflects the deletion.
            onDelete={() => router.back()}
          />
        }
        renderItem={({ item }) => (
          <CommentCard
            comment={item}
            postId={postId as string}
            currentUserId={session?.user?.id}
            onLike={(c) => toggleLike(c)}
            onRepost={(c) => toggleRepost(c)}
            onDelete={(c) => setReplies((prev) => prev.filter((x) => x.id !== c.id))}
          />
        )}
        ListEmptyComponent={<Text style={[styles.empty, { color: colors.subtext }]}>No replies yet.</Text>}
      />
      {replyImage && (
        <View style={[styles.imgPreviewBar, { backgroundColor: colors.card, borderTopColor: colors.border }]}>
          <Image source={{ uri: replyImage }} style={styles.imgPreview} />
          <TouchableOpacity onPress={() => setReplyImage(null)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <Ionicons name="close-circle" size={22} color={colors.subtext} />
          </TouchableOpacity>
        </View>
      )}
      {clip.has && !replyImage && (
        <PasteImageChip
          onPaste={async () => {
            const u = await clip.take();
            if (u) setReplyImage(u);
          }}
          onDismiss={clip.dismiss}
        />
      )}
      <View style={[styles.inputBar, { borderTopColor: colors.border, backgroundColor: colors.card }]}>
        <TouchableOpacity onPress={async () => { const u = await pickCommentImage(); if (u) setReplyImage(u); }} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Ionicons name="image-outline" size={26} color={colors.primary} />
        </TouchableOpacity>
        <PasteTextInput
              onPasteImage={(u) => setReplyImage(u)}
          style={[styles.input, { backgroundColor: colors.inputBg, color: colors.text }]}
          placeholder={replyImage ? 'Add a caption...' : 'Write a reply...'}
          placeholderTextColor={colors.faint}
          value={text}
          onChangeText={setText}
        />
        <TouchableOpacity onPress={submitReply} disabled={sending || (!text.trim() && !replyImage)}>
          {sending ? <ActivityIndicator color={colors.primary} /> : <Ionicons name="send" size={24} color={text.trim() || replyImage ? colors.primary : colors.faint} />}
        </TouchableOpacity>
      </View>
    </KeyboardWrap>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 50, paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  topBarTitle: { fontSize: 17, fontWeight: 'bold' },
  empty: { textAlign: 'center', marginTop: 30 },
  imgPreviewBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 12, paddingVertical: 8, borderTopWidth: 1 },
  imgPreview: { width: 64, height: 64, borderRadius: 10 },
  inputBar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 12, borderTopWidth: 1, gap: 12 },
  input: { flex: 1, borderRadius: 22, paddingHorizontal: 16, paddingVertical: 11, fontSize: 16, minHeight: 44, maxHeight: 120 },
});
