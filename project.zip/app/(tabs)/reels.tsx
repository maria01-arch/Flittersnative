import { useCallback, useEffect, useRef, useState } from 'react';
import { View, FlatList, ActivityIndicator, StyleSheet, LayoutChangeEvent, Dimensions } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/AuthContext';
import ReelItem from '@/components/ReelItem';
import StatusBarScrim from '@/components/StatusBarScrim';
import { ReelSkeleton } from '@/components/Skeleton';
import { usePreferences } from '@/lib/PreferencesContext';
import { Alert } from 'react-native';
import { notifyOnce, fetchMyFlags } from '@/lib/postActions';
import { canPerform, permissionDeniedMessage } from '@/lib/permissions';

const { height: SCREEN_H } = Dimensions.get('window');

export default function ReelsScreen() {
  const { session } = useAuth();
  const { dataSaverMode } = usePreferences();
  // Data saver (default on): only the active reel plus one neighbor each
  // side ever has a real video source. Off: widens to two neighbors each
  // side for a snappier feel on fast swiping — still bounded, not "load
  // everything the list has rendered", which is the bug that was fixed
  // last round.
  const preloadRadius = dataSaverMode ? 1 : 2;
  const [reels, setReels] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeIndex, setActiveIndex] = useState(0);
  const [tabFocused, setTabFocused] = useState(false);
  const mounted = useRef(true);
  // Measured from the actual container, not Dimensions.get('window') — with
  // edge-to-edge enabled, the window dimension doesn't reliably match what
  // this View is actually laid out at, and that mismatch is exactly what
  // was making reels appear letterboxed/misaligned: FlatList was paging by
  // a height the video wasn't actually filling.
  const [pageHeight, setPageHeight] = useState(0);

  const onLayout = (e: LayoutChangeEvent) => {
    const h = e.nativeEvent.layout.height;
    if (h > 0 && h !== pageHeight) setPageHeight(h);
  };

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  useFocusEffect(
    useCallback(() => {
      setTabFocused(true);
      load();
      return () => setTabFocused(false);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
  );

  const load = async () => {
    const { data } = await supabase
      .from('reels')
      .select('*,author:profiles(id,display_name,username,avatar_url,verified,is_authentic,verified_plan),reel_likes(count),comments(count)')
      .order('created_at', { ascending: false })
      .limit(30);
    if (!mounted.current) return;
    // Counts come from the database as single numbers; one small query
    // finds which of these reels I've liked (instead of downloading every
    // like on every reel).
    const likedByMe = new Set<string>();
    if (session?.user?.id && data?.length) {
      const { data: mine } = await supabase
        .from('reel_likes')
        .select('reel_id')
        .eq('user_id', session.user.id)
        .in('reel_id', data.map((r: any) => r.id));
      (mine || []).forEach((l: any) => likedByMe.add(l.reel_id));
    }
    if (!mounted.current) return;
    const countOf = (rel: any) => (Array.isArray(rel) ? Number(rel[0]?.count) || 0 : 0);
    // A video posted to the feed is ALSO a reel. Find that post (same person,
    // same video) so likes, comments and reposts done on either one show on both.
    const postByKey: Record<string, any> = {};
    const urls = [...new Set((data || []).map((r: any) => r.video_url).filter(Boolean))];
    let flags: { liked: Set<string>; reposted: Set<string> } = { liked: new Set(), reposted: new Set() };
    if (urls.length) {
      const { data: posts } = await supabase.from('posts').select('id,user_id,video_url,likes(count),reposts(count),comments(count)').in('video_url', urls);
      (posts || []).forEach((p: any) => {
        const k = `${p.user_id}|${p.video_url}`;
        if (!postByKey[k]) postByKey[k] = p;
      });
      const ids = Object.values(postByKey).map((p: any) => p.id);
      if (ids.length) flags = await fetchMyFlags(ids, session?.user?.id);
    }
    if (!mounted.current) return;
    setReels(
      (data || []).map((r: any) => {
        const p = postByKey[`${r.user_id}|${r.video_url}`];
        const reelLiked = likedByMe.has(r.id);
        const postLiked = !!p && flags.liked.has(p.id);
        return {
          ...r,
          post_id: p?.id || null,
          reel_liked: reelLiked,
          likes_count: countOf(r.reel_likes) + (p ? countOf(p.likes) : 0),
          liked_by_me: reelLiked || postLiked,
          comments_count: countOf(r.comments) + (p ? countOf(p.comments) : 0),
          reposts_count: p ? countOf(p.reposts) : 0,
          reposted_by_me: !!p && flags.reposted.has(p.id),
        };
      })
    );
    setLoading(false);
  };

  const toggleLike = async (reel: any) => {
    const me = session?.user?.id;
    if (!me) return;
    const wasLiked = !!reel.liked_by_me;
    setReels((prev) =>
      prev.map((r) =>
        r.id === reel.id ? { ...r, liked_by_me: !wasLiked, likes_count: Math.max(0, (r.likes_count || 0) + (wasLiked ? -1 : 1)) } : r
      )
    );
    if (wasLiked) {
      // Remove the like wherever it was left (the reel and/or its post).
      await supabase.from('reel_likes').delete().eq('reel_id', reel.id).eq('user_id', me);
      if (reel.post_id) await supabase.from('likes').delete().eq('post_id', reel.post_id).eq('user_id', me);
    } else if (reel.post_id) {
      // A video post's likes live on the post, so they show in the feed too.
      await supabase.from('likes').insert({ post_id: reel.post_id, user_id: me });
      await notifyOnce({ userId: reel.user_id, actorId: me, type: 'like', postId: reel.post_id });
    } else {
      await supabase.from('reel_likes').insert({ reel_id: reel.id, user_id: me });
    }
  };

  const toggleRepost = async (reel: any) => {
    const me = session?.user?.id;
    if (!me || !reel.post_id) return;
    const was = !!reel.reposted_by_me;
    if (!was) {
      const { data: author } = await supabase.from('profiles').select('who_can_repost').eq('id', reel.user_id).maybeSingle();
      const allowed = await canPerform(author?.who_can_repost, reel.user_id, me);
      if (!allowed) {
        Alert.alert("Can't repost", permissionDeniedMessage('who can repost their posts', author?.who_can_repost));
        return;
      }
    }
    setReels((prev) => prev.map((r) => (r.id === reel.id ? { ...r, reposted_by_me: !was, reposts_count: Math.max(0, (r.reposts_count || 0) + (was ? -1 : 1)) } : r)));
    if (was) {
      await supabase.from('reposts').delete().eq('post_id', reel.post_id).eq('user_id', me);
    } else {
      await supabase.from('reposts').insert({ post_id: reel.post_id, user_id: me });
      await notifyOnce({ userId: reel.user_id, actorId: me, type: 'repost', postId: reel.post_id });
    }
  };

  const deleteReel = (reel: any) => {
    Alert.alert('Delete reel', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          setReels((prev) => prev.filter((r) => r.id !== reel.id));
          await supabase.from('reels').delete().eq('id', reel.id).eq('user_id', session?.user?.id);
        },
      },
    ]);
  };

  const bumpCommentCount = (reel: any) => {
    setReels((prev) => prev.map((r) => (r.id === reel.id ? { ...r, comments_count: (r.comments_count || 0) + 1 } : r)));
  };

  const onViewableItemsChanged = useRef(({ viewableItems }: any) => {
    if (!mounted.current) return;
    if (viewableItems.length > 0) setActiveIndex(viewableItems[0].index ?? 0);
  }).current;

  if (loading) {
    return <ReelSkeleton height={pageHeight || SCREEN_H} />;
  }

  return (
    <View style={styles.container} onLayout={onLayout}>
      <StatusBarScrim />
      {pageHeight > 0 && (
        <FlatList
          // Toggling Data Saver changes preloadRadius, but a ReelItem
          // already on screen was built with whatever shouldLoad value it
          // had at mount time — expo-video's player doesn't reliably react
          // to its source argument changing after the fact, so without
          // forcing a remount here, flipping the setting would silently do
          // nothing for anything already rendered (exactly the "no
          // difference" symptom). This key forces every item to be
          // recreated fresh the moment the setting changes, so it's
          // actually guaranteed to take effect rather than depending on
          // video-player internals.
          key={dataSaverMode ? 'saver-on' : 'saver-off'}
          data={reels}
          keyExtractor={(item) => item.id}
          pagingEnabled
          showsVerticalScrollIndicator={false}
          snapToInterval={pageHeight}
          snapToAlignment="start"
          decelerationRate="fast"
          // Without this, a strong fast swipe can carry enough momentum to
          // sail past 2-3 snap points before the list settles — this locks
          // scrolling to exactly one page per gesture, however hard you flick.
          disableIntervalMomentum
          // Matches the measured height exactly, so FlatList's paging math
          // and each item's actual rendered size never disagree.
          getItemLayout={(_, index) => ({ length: pageHeight, offset: pageHeight * index, index })}
          // Defaults render roughly 10 screens' worth of items — for a
          // feed of full-screen videos, that alone meant up to 10 videos
          // existed (and, before the fix in ReelItem, were downloading)
          // at once. This keeps only the active item plus one on each
          // side actually mounted.
          initialNumToRender={preloadRadius * 2 + 1}
          maxToRenderPerBatch={preloadRadius * 2 + 1}
          windowSize={preloadRadius * 2 + 1}
          renderItem={({ item, index }) => (
            <ReelItem
              reel={item}
              height={pageHeight}
              active={tabFocused && index === activeIndex}
              shouldLoad={Math.abs(index - activeIndex) <= preloadRadius}
              isMine={item.user_id === session?.user?.id}
              onLike={toggleLike}
              onRepost={toggleRepost}
              onDelete={deleteReel}
              onCommentPosted={bumpCommentCount}
            />
          )}
          onViewableItemsChanged={onViewableItemsChanged}
          viewabilityConfig={{ itemVisiblePercentThreshold: 60 }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#000' },
});
