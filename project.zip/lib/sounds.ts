import AsyncStorage from '@react-native-async-storage/async-storage';
import { createAudioPlayer, setAudioModeAsync } from 'expo-audio';

// Short, soft app sounds. Each one is a tiny file in assets/sounds.
// They mix with other audio (music keeps playing), stay quiet, and can be
// switched off in Settings → Notifications → Sounds.
export type SoundName = 'typing' | 'incoming' | 'send' | 'like';

// A sound can have several versions; it steps through them in turn (the
// typing "bloops" climb and fall like a little tune).
const SRC: Record<SoundName, any[]> = {
  typing: [], // typing sound removed on purpose — playSound('typing') does nothing
  incoming: [require('../assets/sounds/incoming.wav')],
  send: [require('../assets/sounds/knock.wav')],
  like: [require('../assets/sounds/like.wav')],
};
const turn: Partial<Record<SoundName, number>> = {};
const VOLUME: Record<SoundName, number> = { typing: 0.5, incoming: 0.5, send: 0.6, like: 0.5 };
// A sound won't repeat faster than this (typing signals arrive every few seconds).
const MIN_GAP: Record<SoundName, number> = { typing: 3500, incoming: 250, send: 150, like: 200 };

const KEY = 'sounds_enabled';
let enabled = true;
let loaded = false;
let modeSet = false;
const players: Record<string, any> = {};
const lastPlayed: Partial<Record<SoundName, number>> = {};

async function load() {
  if (loaded) return;
  loaded = true;
  try {
    enabled = (await AsyncStorage.getItem(KEY)) !== 'false';
  } catch {}
}
load();

export async function getSoundsEnabled(): Promise<boolean> {
  await load();
  return enabled;
}
export async function setSoundsEnabled(v: boolean) {
  enabled = v;
  loaded = true;
  try {
    await AsyncStorage.setItem(KEY, v ? 'true' : 'false');
  } catch {}
}

export function playSound(name: SoundName, force = false) {
  if (!enabled) return;
  if (name === 'typing') return; // switched off for good
  const now = Date.now();
  if (!force && now - (lastPlayed[name] || 0) < MIN_GAP[name]) return;
  lastPlayed[name] = now;
  try {
    if (!modeSet) {
      modeSet = true;
      setAudioModeAsync({ playsInSilentMode: false, interruptionMode: 'mixWithOthers' } as any).catch(() => {});
    }
    const i = (turn[name] || 0) % SRC[name].length;
    turn[name] = i + 1;
    const pk = `${name}:${i}`;
    let p = players[pk];
    if (!p) {
      p = createAudioPlayer(SRC[name][i]);
      players[pk] = p;
    }
    p.volume = VOLUME[name];
    Promise.resolve(p.seekTo(0))
      .catch(() => {})
      .then(() => p.play());
  } catch (err) {
    console.warn('[sounds] could not play', name, err);
  }
}
