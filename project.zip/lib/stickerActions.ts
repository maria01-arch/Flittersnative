import { supabase } from './supabase';

// Your own sticker pack (the first one — "My Stickers"), created if missing.
async function myPackId(userId: string): Promise<string | null> {
  const { data } = await supabase.from('sticker_packs').select('id').eq('owner_id', userId).order('created_at', { ascending: true }).limit(1);
  if (data?.[0]) return data[0].id;
  const { data: created } = await supabase.from('sticker_packs').insert({ owner_id: userId, name: 'My Stickers' }).select('id').single();
  return created?.id ?? null;
}

export type StickerResult = { status: 'added' | 'exists' | 'own' | 'error'; count?: number; message?: string };

// Save ONE sticker from a chat into your own pack.
export async function addStickerToMyPack(userId: string, url: string): Promise<StickerResult> {
  const pack = await myPackId(userId);
  if (!pack) return { status: 'error', message: "Couldn't open your sticker pack." };
  const { data: have } = await supabase.from('stickers').select('id').eq('pack_id', pack).eq('media_url', url).limit(1);
  if (have?.length) return { status: 'exists' };
  const { error } = await supabase.from('stickers').insert({ pack_id: pack, media_url: url });
  return error ? { status: 'error', message: error.message } : { status: 'added', count: 1 };
}

// Copy EVERY sticker from the pack this sticker came from into your pack
// (skipping ones you already have). The pack is found by looking the
// sticker's picture up in the `stickers` table.
export async function addFullPack(userId: string, url: string): Promise<StickerResult> {
  const { data: src, error } = await supabase.from('stickers').select('pack_id').eq('media_url', url).limit(1);
  if (error || !src?.[0]) return { status: 'error', message: "Couldn't find the pack this sticker belongs to." };
  const packId = src[0].pack_id;
  const [{ data: items }, { data: pack }] = await Promise.all([
    supabase.from('stickers').select('media_url').eq('pack_id', packId),
    supabase.from('sticker_packs').select('owner_id').eq('id', packId).maybeSingle(),
  ]);
  if (pack?.owner_id === userId) return { status: 'own' };
  if (!items?.length) return { status: 'error', message: "That pack's stickers couldn't be read." };
  const mine = await myPackId(userId);
  if (!mine) return { status: 'error', message: "Couldn't open your sticker pack." };
  const { data: existing } = await supabase.from('stickers').select('media_url').eq('pack_id', mine);
  const have = new Set((existing || []).map((s: any) => s.media_url));
  const rows = items.filter((i: any) => !have.has(i.media_url)).map((i: any) => ({ pack_id: mine, media_url: i.media_url }));
  if (!rows.length) return { status: 'exists' };
  const { error: insErr } = await supabase.from('stickers').insert(rows);
  return insErr ? { status: 'error', message: insErr.message } : { status: 'added', count: rows.length };
}
