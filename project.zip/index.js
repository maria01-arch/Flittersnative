// Loads the closed-app notification task first, then starts the app as usual.
import './lib/pushTask';
import 'expo-router/entry';
