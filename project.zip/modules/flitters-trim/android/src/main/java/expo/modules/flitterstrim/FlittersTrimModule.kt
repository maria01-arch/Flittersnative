package expo.modules.flitterstrim

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.io.File
import java.nio.ByteBuffer

// Cuts a piece out of a video WITHOUT re-encoding it (so it is fast and keeps
// the quality). It copies the already-compressed pictures and sound between
// two moments into a new .mp4 file, using Android's own MediaExtractor and
// MediaMuxer. Because it doesn't re-encode, the cut has to start on a
// "keyframe", so the start can be up to a second or two earlier than asked.
class FlittersTrimModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("FlittersTrim")

    // maxMs: never write more than this much video (0 = no cap). Because the
    // cut starts on a keyframe, it can begin a little before startMs; the cap
    // is counted from where it really begins.
    AsyncFunction("trim") { uri: String, startMs: Double, endMs: Double, maxMs: Double ->
      return@AsyncFunction trimVideo(uri, startMs.toLong(), endMs.toLong(), maxMs.toLong())
    }
  }

  private fun trimVideo(input: String, startMs: Long, endMs: Long, maxMs: Long): Map<String, Any> {
    val context: Context = appContext.reactContext ?: throw IllegalStateException("The app is not ready")
    val source = Uri.parse(input)
    val outFile = File(context.cacheDir, "trim-" + System.currentTimeMillis() + ".mp4")

    val extractor = MediaExtractor()
    var muxer: MediaMuxer? = null
    var muxerStarted = false
    try {
      extractor.setDataSource(context, source, null)

      // Find the picture track and the sound track.
      var videoTrack = -1
      var audioTrack = -1
      for (i in 0 until extractor.trackCount) {
        val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
        if (videoTrack < 0 && mime.startsWith("video/")) videoTrack = i
        if (audioTrack < 0 && mime.startsWith("audio/")) audioTrack = i
      }
      if (videoTrack < 0) throw IllegalStateException("No video found in this file")

      val m = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
      muxer = m

      // Keep the phone-held direction (portrait / landscape) of the video.
      val retriever = MediaMetadataRetriever()
      try {
        retriever.setDataSource(context, source)
        val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        m.setOrientationHint(rotation)
      } catch (e: Exception) {
        // not fatal: the video just keeps its default direction
      } finally {
        retriever.release()
      }

      val outVideo = m.addTrack(extractor.getTrackFormat(videoTrack))
      var outAudio = -1
      if (audioTrack >= 0) {
        try {
          outAudio = m.addTrack(extractor.getTrackFormat(audioTrack))
        } catch (e: Exception) {
          // a sound format an .mp4 can't hold: cut the picture without sound
          audioTrack = -1
        }
      }

      var maxSize = 1024 * 1024
      for (i in intArrayOf(videoTrack, audioTrack)) {
        if (i < 0) continue
        val f = extractor.getTrackFormat(i)
        if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
          maxSize = Math.max(maxSize, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
        }
      }

      val startUs = startMs * 1000L
      var endUs = endMs * 1000L

      // 1) Where is the keyframe at or before the wanted start?
      extractor.selectTrack(videoTrack)
      extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
      val baseUs = extractor.sampleTime
      if (baseUs < 0) throw IllegalStateException("Could not find the start of the video")
      if (maxMs > 0) endUs = Math.min(endUs, baseUs + maxMs * 1000L)

      // 2) Bring the sound to the same moment.
      if (audioTrack >= 0) {
        extractor.selectTrack(audioTrack)
        extractor.seekTo(baseUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
      }

      m.start()
      muxerStarted = true

      val buffer = ByteBuffer.allocate(maxSize)
      val info = MediaCodec.BufferInfo()
      var videoDone = false
      var audioDone = audioTrack < 0
      var wroteVideo = false

      while (!(videoDone && audioDone)) {
        buffer.clear()
        val size = extractor.readSampleData(buffer, 0)
        if (size < 0) break
        val time = extractor.sampleTime
        val track = extractor.sampleTrackIndex
        if (time < 0) break

        if (time > endUs) {
          if (track == videoTrack) videoDone = true
          if (track == audioTrack) audioDone = true
          extractor.advance()
          continue
        }

        if (track == videoTrack) {
          info.offset = 0
          info.size = size
          info.presentationTimeUs = Math.max(0L, time - baseUs)
          info.flags = if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
          m.writeSampleData(outVideo, buffer, info)
          wroteVideo = true
        } else if (track == audioTrack && time >= baseUs) {
          info.offset = 0
          info.size = size
          info.presentationTimeUs = time - baseUs
          info.flags = MediaCodec.BUFFER_FLAG_KEY_FRAME
          m.writeSampleData(outAudio, buffer, info)
        }
        extractor.advance()
      }

      if (!wroteVideo) throw IllegalStateException("Nothing to cut: the chosen part is empty")
      m.stop()
      muxerStarted = false
      return mapOf(
        "uri" to Uri.fromFile(outFile).toString(),
        "startMs" to (baseUs / 1000L).toDouble(),
        "durationMs" to ((endUs - baseUs) / 1000L).toDouble()
      )
    } catch (e: Exception) {
      outFile.delete()
      throw e
    } finally {
      try {
        if (muxerStarted) muxer?.stop()
      } catch (e: Exception) {
      }
      try {
        muxer?.release()
      } catch (e: Exception) {
      }
      extractor.release()
    }
  }
}
